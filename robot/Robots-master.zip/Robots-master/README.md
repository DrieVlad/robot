# Robots
The project to learn OO design concepts and MDI application development in Java
