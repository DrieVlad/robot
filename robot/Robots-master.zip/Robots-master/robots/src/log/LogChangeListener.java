package log;

public interface LogChangeListener
{
    public void onLogChanged(); 
}
